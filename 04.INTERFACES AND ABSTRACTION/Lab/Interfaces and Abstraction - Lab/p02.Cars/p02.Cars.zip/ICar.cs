﻿namespace Cars
{
    public interface ICar
    {
        string Start();

        string Stop();
    }
}
