﻿using System;
using System.Collections.Generic;
using System.Text;

public class Track
{
    public Track()
    {

    }

   public int LapsNumber { get; set; }
   
   public int TrackLength { get; set; }
}

