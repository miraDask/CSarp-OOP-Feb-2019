﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class Engine
{
    private RaceTower controller;

    public Engine()
    {
        this.controller = new RaceTower();
    }

    public void Run()
    {
        while (true)
        {
            var input = Console.ReadLine().Split();
            var command = input[0];
            var args = input.Skip(1).ToList();

            string result = string.Empty;

            if (command.Contains("Box"))
            {
                this.controller.DriverBoxes(args);
            }
            else
            {
                result = (string)this.controller
                    .GetType()
                    .GetMethods()
                    .FirstOrDefault(m => m.Name.Contains(command)) 
                    .Invoke(this.controller, new object[] { args });
            }
        }
    }
}

