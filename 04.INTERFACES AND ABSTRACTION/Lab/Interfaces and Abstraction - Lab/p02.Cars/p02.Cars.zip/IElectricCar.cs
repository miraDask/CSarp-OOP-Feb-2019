﻿namespace Cars
{
    interface IElectricCar
    {
        int Batteries { get;}
    }
}
